from setuptools import setup, find_packages

setup(
    name='ccf_utilities',
    version='1.0.0',
    packages=find_packages(),
    # ...other metadata...
    author="Aamar Shahzad"
)
